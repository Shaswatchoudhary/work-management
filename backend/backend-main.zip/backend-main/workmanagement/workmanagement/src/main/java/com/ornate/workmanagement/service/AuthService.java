package com.ornate.workmanagement.service;

import com.ornate.workmanagement.tdo.*;

public interface AuthService {

    RegisterResponse register(RegisterRequest request);

    LoginResponse login(LoginRequest request);

}