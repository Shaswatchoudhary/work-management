package com.ornate.workmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkmanagementApplication.class, args);
	}

}
