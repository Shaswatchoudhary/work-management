package com.ornate.workmanagement.service;

import com.ornate.workmanagement.tdo.*;
import com.ornate.workmanagement.tdo.RegisterRequest;
import com.ornate.workmanagement.entity.User;
import com.ornate.workmanagement.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    private final UserRepository repository;

    public AuthServiceImpl(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public RegisterResponse register(RegisterRequest request) {

        // Email already exists check
        if (repository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        // Password match check
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new RuntimeException(
                    "Password and Confirm Password do not match");
        }

        // Create User Object
        User user = new User();

        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setRole(request.getRole());

        // Save into DB
        User savedUser = repository.save(user);

        // Return Response
        return new RegisterResponse(
                savedUser.getId(),
                savedUser.getFullName(),
                savedUser.getEmail(),
                savedUser.getPassword(),
                savedUser.getRole(),
                savedUser.getCreatedAt()
        );
    }

    @Override
    public LoginResponse login(LoginRequest request) {

        User user = repository
                .findByEmail(request.getEmail())
                .orElseThrow(() ->
                        new RuntimeException("User Not Found"));

        if (!user.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("Invalid Password");
        }

        return new LoginResponse(
                user.getId(),
                user.getFullName(),
                user.getRole(),
                user.getEmail(),
                user.getCreatedAt()
        );
    }
}