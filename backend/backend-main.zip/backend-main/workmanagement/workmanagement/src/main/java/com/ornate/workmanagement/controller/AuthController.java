package com.ornate.workmanagement.controller;

import com.ornate.workmanagement.tdo.ApiResponse;
import com.ornate.workmanagement.tdo.LoginRequest;
import com.ornate.workmanagement.tdo.LoginResponse;
import com.ornate.workmanagement.tdo.RegisterRequest;
import com.ornate.workmanagement.tdo.RegisterResponse;
import com.ornate.workmanagement.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("*")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public ApiResponse<RegisterResponse> register(
            @RequestBody RegisterRequest request) {

        RegisterResponse response =
                service.register(request);

        return new ApiResponse<>(
                "User Registered Successfully",
                response
        );
    }

    @PostMapping("/login")
    public LoginResponse login(
            @RequestBody LoginRequest request) {

        return service.login(request);
    }
}