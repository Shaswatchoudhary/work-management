package com.ornate.workmanagement.tdo;

import java.time.LocalDateTime;

public class LoginResponse {

    // Getter Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    private Long id;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    private String name;
    private String role;
    private String email;
    private LocalDateTime createdAt;

    public LoginResponse() {
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LoginResponse(
            Long id,
            String name,
            String role,
            String email,
            LocalDateTime createdAt) {

        this.id = id;
        this.name = name;
        this.role = role;
        this.email= email;
        this.createdAt= createdAt;
    }


}